# Simple-Quiz-HTML-CSS-JavaScript
Build a simple quiz using HTML, CSS and JavaScript

## Youtube tutorials:
### HTML,CSS: 
https://youtu.be/28pArrDzQII
### JavaScript: 
https://youtu.be/vj6bAznjzxo

